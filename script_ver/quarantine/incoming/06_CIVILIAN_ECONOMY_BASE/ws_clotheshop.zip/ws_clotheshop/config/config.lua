WS = {}

WS.settings = {
    getSharedObject = "esx:getSharedObject",
    price = 10000, -- price for each change --
    saveprice = 10000,
    useESXLegacy = false, -- or 1.2 --
    useOxMysql = false, -- !! DO NOT CHANGE, SCRIPT AUTO. DETECTS IF YOUR SERVER IS USING MYSQL ASYNC OR OXMYSQL !!
}

WS.blip = {
    label = 'Kleidungsladen',
    sprite = 73,
    colour = 47,
    scale = 0.5,
    display = 4,
}

WS.cam = {
    offset = {0.0, 1.5, 0.8}, -- x, y, z offset coords of the camera: https://docs.fivem.net/natives/?_0x1899F328B0E12848
    fov = 75.0,
}

WS.marker = {
    typ = 1,
    move = false,
    rotate = false,
    enabled = true,
    drawDistance = 15.0,
    color = {
        r = 251,
        g = 3,
        b = 99,
        t = 140
    },
    size = {
        x = 1.5,
        y = 1.5,
        z = 1.0
    },
    offsetz = 0.0
}

WS.positions = {
	vector3(72.3, -1399.1, 28.4),
	vector3(-1045.16, -2827.31, 26.69),
	vector3(-703.8, -152.3, 36.4),
	vector3(-167.9, -299.0, 38.7),
	vector3(428.7, -800.1, 28.5),
	vector3(-829.4, -1073.7, 10.3),
	vector3(-1447.8, -242.5, 48.8),
	vector3(11.6, 6514.2, 30.9),
	vector3(123.6, -219.4, 53.6),
	vector3(1696.3, 4829.3, 41.1),
	vector3(618.1, 2759.6, 41.1),
	vector3(1190.6, 2713.4, 37.2),
	vector3(-1193.4, -772.3, 16.3),
	vector3(-3172.5, 1048.1, 19.9),
	vector3(-1108.4, 2708.9, 18.1),
	vector3(4489.08,-4452.39,3.21),
	vector3(-78.1570, -810.7851, 242.3858),
	vector3(-438.26, -308.68, 33.91), -- medic
	vector3(462.7127, -999.1390, 29.6896), -- police
	vector3(1841.2512, 3679.4534, 33.1893), -- lssd
	vector3(-2363.0049, 3246.3318, 91.9037), -- army 
	vector3(1680.6918, 2579.0640, 44.9115), -- sg
	vector3(151.8960, -736.3242, 241.1520), -- fib
	vector3(896.2662, -2100.5999, 33.8886), -- mechanic
	vector3(1049.9653, -3105.1672, -39.9999) -- lagerhalle
}

WS.clothes = {
    -- "mask_1",
    "helmet_1",
    "chain_1",
    "glasses_1", 
    "torso_1",
    "tshirt_1",
    "bags_1",
    "bproof_1",
    "arms",
    "pants_1", 
    "decals_1", 
    "shoes_1",
}
-- current available skinchanger components (+ the _2 version this means the color variation): 
-- mask_1, helmet_1, chain_1, glasses_1, torso_1, tshirt_1, bags_1, bproof_1, arms, pants_1, decals_1, shoes_1

WS.blacklist = {
    --["mask_1"] = {23, 25}, -- example how to blacklist specific ids
    ["mask_1"] = {},
    ["helmet_1"] = {},
    ["chain_1"] = {},
    ["glasses_1"] = {}, 
    ["torso_1"] = {},
    ["tshirt_1"] = {},
    ["bags_1"] = {},
    ["bproof_1"] = {},
    ["arms"] = {},
    ["pants_1"] = {}, 
    ["decals_1"] = {}, 
    ["shoes_1"] = {},
    
}

WS.blacklistedNameComponents = {"<", ">"}

WS.locales = {
    ["locale"] = {
        ['server_name'] = 'ESX Roleplay',
        ['cloth_shop'] = {
            ['shop_title'] = {
                ['shop_title'] = 'Kleidungsladen',
                ['left_top'] = 'Premium',
                ['left_middle'] = 'Kleidungsladen',
                ['left_bottom'] = 'Willkommen im besten Luxusbekleidungsgeschäft des gesamten Bundesstaates',
            },
            ['texts'] = {
                ['rotate'] = 'Drehen Sie den PLAYER um 360°',
                ['choice'] = 'Kleidervariation zu wählen',
            },
            ['change_cloth'] = {
                ['title'] = 'Kleidungsvariante',
                ['view'] = 'Aussicht',
                ['color'] = 'Farbe',
                ['buy'] = 'Kaufen',
            },
            ['components'] = {
                ['title'] = 'Kategorie'
            }
        },
        ['outfit_selection'] = {
            ['selection'] = {
                ['title'] = 'Wichtig',
                ['sub_title'] = 'Sie möchten den Kleiderladen betreten oder bestehende Outfits verwalten',
                ['cloth_shop'] = 'Kleidungsladen',
                ['outfits'] = 'Outfits',
            },
            ['change_name'] = {
                ['input_text'] = 'Ändern Sie den Namen',
                ['confirm'] = 'Bestätigen'
            },
            ['save'] = {
                ['title'] = 'Wichtig',
                ['sub_title'] = 'Möchtest du das Outfit speichern? (+'..WS.settings.saveprice..'$)',
                ['save'] = 'Speichern',
                ['remove'] = "Nicht Speichern",
            },
        },
        ['wardrobe'] = {
            ['wardrobe_title'] = {
                ['top'] = 'Du',
                ['middle'] = 'Kleiderschrank',
                ['bottom'] = 'Ihre Kleidung wird hier aufbewahrt, Sie können sie jederzeit wechseln oder löschen',
            }
        },
    },
    ['game'] = {
        ['press_e'] = 'Drücke ~INPUT_PICKUP~ um den Kleiderladen zu öffnen',
        ['has_enough_money'] = 'Sie haben erfolgreich bezahlt %s$ für das Outfit', -- %s is the money value
        ['has_not_enough_money_outfit'] = "Du hast nicht genug Geld, um das Outfit zu bezahlen",
        ['has_not_enough_money_outfitsave'] = "Du hast nicht genug Geld, um das Outfit zu bezahlen",
    },
    ["clothes"] = {
        ['mask_1'] = {
            ["color"] = 'mask_2',
            ["svg"] = 'mask',
            ["label"] = 'Maske'
        },
        ['helmet_1'] = {
            ["color"] = 'helmet_2',
            ["svg"] = 'cap',
            ["label"] = 'Helm'
        },
        ['chain_1'] = {
            ["color"] = 'chain_2',
            ["svg"] = 'chain',
            ["label"] = 'Kette'
        },
        ['glasses_1'] = {
            ["color"] = 'glasses_2',
            ["svg"] = 'glasses',
            ["label"] = 'Brille'
        },
        ['torso_1'] = {
            ["color"] = 'torso_2',
            ["svg"] = 'torso',
            ["label"] = 'Torso'
        },
        ['tshirt_1'] = {
            ["color"] = 'tshirt_2',
            ["svg"] = 'tshirt',
            ["label"] = 'TShirt'
        },
        ['bags_1'] = {
            ["color"] = 'bags_2',
            ["svg"] = 'backpack',
            ["label"] = 'Rucksack'
        },
        ['bproof_1'] = {
            ["color"] = 'bproof_2',
            ["svg"] = 'vest',
            ["label"] = 'Weste'
        },
        ['arms'] = {
            ["color"] = nil, -- there is no available color component
            ["svg"] = 'arms',
            ["label"] = 'Arme'
        },
        ['pants_1'] = {
            ["color"] = 'pants_2',
            ["svg"] = 'trousers',
            ["label"] = 'Hose'
        },
        ['decals_1'] = {
            ["color"] = 'decals_2',
            ["svg"] = 'watch',
            ["label"] = 'Uhr'
        },
        ['shoes_1'] = {
            ["color"] = 'shoes_2',
            ["svg"] = 'shoes',
            ["label"] = 'Schuhe'
        },
    }
}

-- SERVER FUNCTIONS  --
function isBlacklistedName(name)
    for k, v in ipairs(WS.blacklistedNameComponents) do
        if string.find(name, v) then
            return true
        end
    end
    return false
end

function getPlayerMoney(xPlayer)
    if WS.settings.useESXLegacy then
        return xPlayer.getAccount('money').money -- both work in legacy --
    else
        return xPlayer.getMoney() -- esx 1.1 --
    end
end

function removePlayerMoney(xPlayer, amount)
    if WS.settings.useESXLegacy then
        xPlayer.removeAccountMoney('money', amount)
    else
        xPlayer.removeMoney(amount)
    end
end

-- CLIENT FUNTIONS --

-- if you want to use your own skinchanger, call the cb with the specific data skin --
-- this gets the player skin (table) --
function getSkin(cb)
    TriggerEvent('skinchanger:getSkin', function(skin)
        cb(skin)
    end)
end

-- this gets the min & max values of all available skin-components --
function getMaxValues(cb)
    TriggerEvent('skinchanger:getData', function(components, maxVals)
        cb(components, maxVals)
    end)
end

-- change the specific component --
function changeSkin(comp, index)
    TriggerEvent('skinchanger:change', comp, index)
end

function saveSkin(skin)
    TriggerServerEvent('esx_skin:save', skin)
end

-- load skin --
function loadSkin(skin)
    TriggerEvent('skinchanger:loadSkin', skin)
end

function loadClothes(clothes)
    getSkin(function(skin)
        TriggerEvent('skinchanger:loadClothes', skin, clothes)
    end)
end

function Notify(msg)
    TriggerEvent("notifications", "info", "Information", msg, 5000)
end

function HelpNotify(msg)
    SetTextComponentFormat("STRING")
	AddTextComponentString(msg)
	DisplayHelpTextFromStringLabel(0, 0, 1, -1)
end